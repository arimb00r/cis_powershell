from django.contrib import admin
from django.urls import path, include
from allauth.account.views import LogoutView
from accounts.views import noAccessView, redirectView, redirectLoginView

urlpatterns = [
    # User management
    path('', redirectLoginView, name='redirectLoginView'),
    path('accout/', include('allauth.urls')),

    # Django admin

    path('admin/login/', noAccessView, name='noAccessView'),
    path('admin/logout/', redirectView, name='redirectView'),
    path('admin/', admin.site.urls, name='admin'),
]
