# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.forms import ModelForm


class Newsupdate(models.Model):
    PENDING_VALIDATION = 'pending for content validation'
    PENDING_APPROVAL = 'pending for approval'
    PENDING_REJECTION = 'pending for rejection'
    APPROVED = 'approved'
    REJECTED = 'rejected'

    newsstatus_choices = (
        (PENDING_VALIDATION, PENDING_VALIDATION),
        (PENDING_APPROVAL, PENDING_APPROVAL),
        (PENDING_REJECTION, PENDING_REJECTION),
        (APPROVED, APPROVED),
        (REJECTED, REJECTED),
    )

    newsid = models.IntegerField(db_column='NewsID', primary_key=True, editable=False)  # Field name made lowercase.
    date_utc = models.DateTimeField(db_column='Date-UTC', editable=False)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    referencelinktimezone = models.CharField(db_column='ReferenceLinkTimezone', max_length=255)  # Field name made lowercase.
    heading = models.CharField(db_column='Heading', max_length=255)  # Field name made lowercase.
    description = models.CharField(db_column='Description', max_length=255)  # Field name made lowercase.
    reference = models.CharField(db_column='Reference', max_length=255)  # Field name made lowercase.
    tagcategorization = models.TextField(db_column='TagCategorization')  # Field name made lowercase.
    primarytag = models.CharField(db_column='PrimaryTag', max_length=255)  # Field name made lowercase.
    industry = models.CharField(db_column='Industry', max_length=255)  # Field name made lowercase.
    country = models.CharField(db_column='Country', max_length=255)  # Field name made lowercase.
    timelinequalifier = models.CharField(db_column='TimelineQualifier', max_length=255)  # Field name made lowercase.
    similarnewsid = models.TextField(db_column='Similarnewsid', blank=True)  # Field name made lowercase.
    newsstatus = models.CharField(db_column='NewsStatus', choices=newsstatus_choices, max_length=255)  # Field name made lowercase.
    updatedby = models.CharField(db_column='Updatedby', max_length=255, editable=False)  # Field name made lowercase.


    class Meta:
        db_table = 'newsupdate'




