import datetime
import pytz
import ast

from django.contrib import admin
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from django.forms import Textarea
from django.http import HttpResponseRedirect

from django.db import models
from django.shortcuts import redirect

from .models import Newsupdate
from allauth.account.models import EmailAddress
from allauth.socialaccount.models import SocialAccount, SocialToken, SocialApp
from django.contrib.sites.models import Site

from django import forms


def _get_now_formatted() -> str:
    return _get_now_datetime().strftime("%Y-%m-%d %H:%M:%S")


def _get_two_months_ago_formatted() -> str:
    now =_get_now_datetime()
    return now.replace(month=now.month-2).strftime("%Y-%m-%d %H:%M:%S")


def _get_now_datetime() -> datetime.datetime:
    tz = pytz.timezone("UTC")
    now = datetime.datetime.now()
    return now


PRIMARY_TAG_CHOICES = [
    ('Cyberattack', 'Cyberattack'),
    ('Malware', 'Malware'),
    ('Vulnerability', 'Vulnerability'),
    ('Breach', 'Breach'),
]
TAGCATEGORIZATION_CHOICES = [
    ('CVE', 'CVE'),
    ('TA', 'TA'),
    ('MalwareType', 'MalwareType'),
    ('CyberAttackTool', 'CyberAttackTool'),
]


class MyWidget(forms.SelectMultiple):

    def format_value(self, value):
        """Return selected values as a list."""
        if value is None and self.allow_multiple_selected:
            return []
        if not isinstance(value, (tuple, list)):
            # This means it should be a comma delimited list of items so parse it
            value = value.split(',')

        return [force_text(v) if v is not None else '' for v in value]


class SimpleForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(SimpleForm, self).__init__(*args, **kwargs)
        self.timelinequalifier_list = tuple([(i,i) for i in self.instance.tagcategorization.split(',')]) if self.instance else ()
        self.fields['timelinequalifier'].choices = self.timelinequalifier_list


    list_of_tuples = []
    for item in Newsupdate.objects.filter(date_utc__range=[_get_two_months_ago_formatted(), _get_now_formatted()],
                                          newsstatus='approved'):
        list_of_tuples.append((item.newsid, item.heading))

    SimilarnewsID_CHOISES = tuple(list_of_tuples)



    primarytag = forms.MultipleChoiceField(
        # widget=forms.SelectMultiple,
        widget=MyWidget,
        required=True,
        choices=PRIMARY_TAG_CHOICES,
    )

    tagcategorization = forms.MultipleChoiceField(
        widget=MyWidget,
        required=True,
        choices=TAGCATEGORIZATION_CHOICES,
    )
    # tagcategorization.widget.template_name = 'custom.html'


    similarnewsid = forms.MultipleChoiceField(
        widget=MyWidget,
        required=True,
        choices=SimilarnewsID_CHOISES,
    )
    similarnewsid.widget.template_name = 'custom.html'

    timelinequalifier_list = ()

    timelinequalifier = forms.MultipleChoiceField(
        widget=MyWidget,
        required=False,
        choices=timelinequalifier_list,
    )


    class Meta:
        model = Newsupdate
        fields = '__all__'


class PtagListFilter(admin.SimpleListFilter):
    # Human-readable title which will be displayed in the
    # right admin sidebar just above the filter options.
    title = _('primary tag')

    # Parameter for the filter that will be used in the URL query.
    parameter_name = 'ptag'

    list_of_filters = []

    def lookups(self, request, model_admin):
        """
        Returns a list of tuples. The first element in each
        tuple is the coded value for the option that will
        appear in the URL query. The second element is the
        human-readable name for the option that will appear
        in the right sidebar.
        """

        for ptag in Newsupdate.objects.filter():
            self.list_of_filters += [i.strip().title() for i in ptag.primarytag.split(',')]

        return (
            ((i, _(i)) for i in list(set(self.list_of_filters)))
        )

    def queryset(self, request, queryset):
        """
        Returns the filtered queryset based on the value
        provided in the query string and retrievable via
        `self.value()`.
        """
        for i in self.list_of_filters:
            if self.value() == i or self.value() == i.lower():
                return queryset.filter(primarytag__regex=fr'{i}|{i.lower()}')


@admin.register(Newsupdate)
class newsAdmin(admin.ModelAdmin):
    list_display = ('heading', 'newsstatus', 'country', 'industry', 'date_utc', 'primarytag', 'updatedby')
    search_fields = ('heading', 'description', 'country', 'industry')
    list_filter = ('newsstatus', 'country', PtagListFilter,)
    form = SimpleForm

    formfield_overrides = {
        models.CharField: {'widget': Textarea()},
        models.TextField: {'widget': Textarea(attrs={'rows': 2})},
    }

    def get_readonly_fields(self, request, obj=None):
        if obj:
            if obj.newsstatus == 'approved':
                return ['newsstatus','heading','description','reference', 'primarytag', 'industry', 'country', 'similarnewsid', 'timelinequalifier']
            else:
                return ['newsstatus',]
        else:
            return ['newsstatus',]

    def changeform_view(self, request, object_id=None, form_url='', extra_context=None):

        if Newsupdate.objects.filter(pk=object_id).exists():
            self.initial_object = Newsupdate.objects.get(pk=object_id)
        return super(newsAdmin, self)._changeform_view(request, object_id, form_url, extra_context)

    def render_change_form(self, request, context, add=False, change=False, form_url='', obj=None):
        if add:
            self.change_form_template = self.add_form_template
        else:
            obj.primarytag = obj.primarytag.split(',')
            obj.tagcategorization = obj.tagcategorization.split(',')
            obj.similarnewsid = obj.similarnewsid.split(',')
            try:
                obj.timelinequalifier = obj.timlinequalifier.split(',')
            except:
                pass
            if str(obj.updatedby) == str(request.user) or obj.newsstatus == 'approved':
                self.change_form_template = None
            else:
                if obj.newsstatus == 'pending for rejection':
                    self.change_form_template = "account/admin_changeform_rejection.html"
                else:
                    self.change_form_template = "account/admin_changeform.html"

        return super(newsAdmin, self).render_change_form(request, context, add, change, form_url, obj)

    def response_delete(self, request, obj_display, obj_id):
        return redirect("/admin/news/newsupdate/")

    def response_change(self, request, obj):
        def error_message():
            self.initial_object.save()
            self.message_user(request, "You cannot edit and approve at the same time! All changes are deleted.", level='error')

        def is_clean():
            if obj.pk is not None:
                initial = self.initial_object
                initial_json, final_json = initial.__dict__.copy(), obj.__dict__.copy()
                initial_json.pop('_state'), final_json.pop('_state')
                only_changed_fields = None
                for k in initial_json:
                    if (final_json[k].strip() if type('asd') == type(final_json[k]) else final_json[k]) \
                            != (initial_json[k].strip() if type('asd') == type(final_json[k]) else initial_json[k]):
                        only_changed_fields = {k: {'final_value': final_json[k],
                                                   'initial_value':  initial_json[k]}}
                print(only_changed_fields)
                if only_changed_fields:
                    return False
                return True

        if "_approve" in request.POST:
            if is_clean():
                obj.updatedby = str(request.user)
                obj.date_utc = _get_now_datetime()
                if obj.newsstatus == 'pending for approval':
                    obj.newsstatus = 'approved'
                    self.save_model(request, obj, None, None)
                elif obj.newsstatus == 'pending for rejection':
                    obj.newsstatus = 'rejected'
                    self.delete_model(request, obj)
                    self.message_user(request, f"Instance was deleted.")
                    return HttpResponseRedirect(".")
                elif obj.newsstatus == 'pending for content validation':
                    obj.newsstatus = 'approved'
                    self.save_model(request, obj, None, None)
                self.message_user(request, f"News status changed to {obj.newsstatus}")
            else:
                error_message()
            return redirect("/admin/news/newsupdate/")
        elif "_reject" in request.POST:
            if is_clean():
                obj.date_utc = _get_now_datetime()
                obj.updatedby = str(request.user)
                if obj.newsstatus == 'pending for content validation':
                    obj.newsstatus = 'rejected'
                elif obj.newsstatus == 'pending for approval':
                    obj.newsstatus = 'rejected'
                obj.delete()
                self.message_user(request, f"News status changed to {obj.newsstatus}")
            else:
                error_message()
            return redirect("/admin/news/newsupdate/")
        else:
            if not is_clean():
                obj.date_utc = _get_now_datetime()
                if obj.newsstatus == 'pending for rejection':
                    obj.newsstatus = 'pending for content validation'
                obj.newsstatus = 'pending for approval'
                obj.updatedby = str(request.user)
                self.save_model(request, obj, None, None)

        return super().response_change(request, obj)

    def save_model(self, request, obj, form, change):
        obj.date_utc = _get_now_datetime()
        if obj.similarnewsid is None or obj.similarnewsid == '':
            obj.similarnewsid = 'NA'
        if obj.newsstatus is None or obj.newsstatus == '':
            obj.newsstatus = 'pending for content validation'
        obj.updatedby = str(request.user)

        print(type(obj.primarytag))
        print(obj.primarytag)
        try:
            obj.primarytag = ast.literal_eval(obj.primarytag)
            obj.primarytag = [n.strip() for n in obj.primarytag]
            if type(obj.primarytag) == type([1,2]):
                obj.primarytag = ','.join(obj.primarytag)

            obj.tagcategorization= ast.literal_eval(obj.tagcategorization)
            obj.tagcategorization = [n.strip() for n in obj.tagcategorization]
            if type(obj.tagcategorization) == type([1, 2]):
                obj.tagcategorization = ','.join(obj.tagcategorization)

            obj.similarnewsid = ast.literal_eval(obj.similarnewsid)
            obj.similarnewsid = [n.strip() for n in obj.similarnewsid]
            if type(obj.similarnewsid) == type([1, 2]):
                obj.similarnewsid = ','.join(obj.similarnewsid)


            try:
                obj.timelinequalifier = ast.literal_eval(obj.timelinequalifier)
                obj.timelinequalifier = [n.strip() for n in obj.timelinequalifier]
                if type(obj.timelinequalifier) == type([1, 2]):
                    obj.timelinequalifier = ','.join(obj.timelinequalifier)
            except:
                pass

        except:
            pass
        print(type(obj.primarytag))
        print(obj.primarytag)
        obj.save()


admin.site.site_header = 'Newsupdate'
admin.site.unregister(EmailAddress)
admin.site.unregister(SocialAccount)
admin.site.unregister(SocialToken)
admin.site.unregister(SocialApp)
admin.site.unregister(Site)