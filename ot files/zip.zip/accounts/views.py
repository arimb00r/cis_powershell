from django.http import HttpResponse
from django.shortcuts import redirect


def noAccessView(request):
    return HttpResponse("Your account is not approved by admin.")


def redirectView(request):
    return redirect('/accout/logout/')


def redirectLoginView(request):
    return redirect('/accout/login/')
