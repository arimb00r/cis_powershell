from django import forms

from captcha.fields import ReCaptchaField
from allauth.account.forms import LoginForm


class AllauthSigninForm(LoginForm):
    # https://developers.google.com/recaptcha/docs/display
    # https://github.com/praekelt/django-recaptcha

    def __init__(self, *args, **kwargs):
        super(AllauthSigninForm, self).__init__(*args, **kwargs)
        self.fields['captcha'] = ReCaptchaField(public_key='6Lf6idcZAAAAALdvfbswkS_euarqoTwUSXuLY5iG',
                                                private_key='6Lf6idcZAAAAAMAUD47DMevh7BsI3qZBGzILjR1-')